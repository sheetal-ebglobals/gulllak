<?php
$id     = $_REQUEST['id'];
$userId = $_REQUEST['userId'];
$type   = $_REQUEST['type'];
require('connection.php');
//echo "$id $userId $type";

switch ($type) {
    case 'follow':
        $sql = 'SELECT * 
        FROM follower where id=' . $userId;
        
        $query     = mysqli_query($conn, $sql);
        $row       = mysqli_fetch_array($query);
        $following = explode(',', $row['following']);
        array_push($following, $id);
        $following = implode($following, ',');
        $sql       = 'UPDATE follower
        SET following="' . $following . '"  where id=' . $userId;
        if (mysqli_query($conn, $sql)) {
            echo "Unfollow";
        } else {
            //echo $sql;
        }
        
        break;
    
    case 'unfollow':
        $sql = 'SELECT * 
        FROM follower where id=' . $userId;
        
        $query     = mysqli_query($conn, $sql);
        $row       = mysqli_fetch_array($query);
        $following = explode(',', $row['following']);
        //print_r($following);die;
        array_pop($following);
        $following = implode($following, ',');
        $sql       = 'UPDATE follower
        SET following="' . $following . '"  where id=' . $userId;
        if (mysqli_query($conn, $sql)) {
            echo "follow";
        } else {
            //echo $sql;
        }
        break;
    
    default:
        echo "not good";
}
?>